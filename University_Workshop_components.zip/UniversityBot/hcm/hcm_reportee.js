"use strict"
const https = require('https');
const hcmcommon =require("./hcm_common.js");


module.exports  = {
	metadata: () => ({
        "name": "HCMReporteeService",
        "properties": {
            "fullname": { "type": "string", "required": true },
            "testu":  {"type": "string", "required": true},
            "testp" :  {"type": "string", "required": true}
        },
        "supportedActions": []
    }),

    invoke: (conversation, done) =>{
        // converstaion reply result
        var botRes = "";

        // Get query parameters' value from Bot converstation for HCM Basic API
        let fullname = String(conversation.properties().fullname).trim().toLowerCase().split(' ');

        // basic auth username and password
        let username = String(conversation.properties().testu);
        let passw  = String(conversation.properties().testp);

        conversation.logger().info('username' + username);
        conversation.logger().info('passw' + passw);


        if(fullname !== null || fullname !== ''){
            botRes = hcmcommon.getHCMReportee(conversation, fullname, username, passw);
            conversation.reply({ text : botRes});
        }else {
            botRes = "Please make sure you type the correct words!";
            conversation.reply({text: botRes});
        }

        conversation.transition();
        done();
    }
}