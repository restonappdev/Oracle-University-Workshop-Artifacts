"use strict"

const https = require('https');
const Joi = require('joi');
const MessageModel = require('../MessageModel')(Joi);
const rp = require('request-promise');
const fs = require('fs')

const hcmcommon = require("./hcm_common.js");

const reportkeys = ["professor", "professors", "teacher", "teachers"];

function getImage (username, passw, conversation, imageCallUrl){
    var imageStr = "";
    var done2 = false;
    var options = {
            "method": "GET",
            "url": imageCallUrl.toString().trim(),
            encoding: null,
            port: 443,
            auth: {
              user: username,
              password: passw
            }     
    };
  
  rp.get(options)
  .then(function (res) {
    imageStr = Buffer.from(res, 'utf8').toString("base64");
    console.log(imageStr.trim());
    done2= true;
  });
  require('deasync').loopWhile(function(){return !done2;});
  return "data:image/jpeg;base64," + imageStr.trim();
}

module.exports  = {
	metadata: () => ({
        "name": "HCMBasicWebService",
        "properties": {
            "fullname": { "type": "string", "required": true },
            "fieldattr": {"type": "string", "required": true},
            "testu": {"type": "string", "required": true},
            "testp" : {"type": "string", "required": true}
        },
        "supportedActions": [
            "showlist",
            "nonlist"
        ]
    }),

    invoke:  (conversation, done) =>{

        // get query parameters values from Bot converstation for HCM Basic API
    	let fullname = String(conversation.properties().fullname).trim().toLowerCase().split(' ');
        let firstname = fullname[0].trim().charAt(0).toUpperCase() + fullname[0].substring(1);
        let lastname = fullname[1].trim().charAt(0).toUpperCase() + fullname[1].substring(1);

    	let fieldattr = String(conversation.properties().fieldattr).trim().toLowerCase();

        // basic auth username and password
        let username = String(conversation.properties().testu);
        let passw  = String(conversation.properties().testp);

        conversation.logger().info('username' + username);
        conversation.logger().info('passw' + passw);


        // get response body based on firstname and lastname provided
        let commonBody =  hcmcommon.getHCMBasicBody(conversation, firstname,lastname, username, passw);

        // define some variables
        let botRes = "";
        let fieldName = ""
        let isList = false;

        // trace and debug information to backend log
        conversation.logger().info("fullname - " + fullname);
        conversation.logger().info("filedattr - "+ fieldattr);
         
    	if((fullname !== null || fullname !== '') && (commonBody != "")){
            
            // if you request reportee
            if(reportkeys.includes(fieldattr)){
                //call reportee service
                 botRes = hcmcommon.getHCMReportee(conversation, fullname, username, passw);
                 
                 isList = true;
                 conversation.variable("basicRes", botRes.trim());
            }else{
                let basicCard = hcmcommon.getHCMBasicCard(conversation, fullname, username, passw);
                conversation.logger().info(basicCard);
                
                if(typeof basicCard !== "undefined"){
                    // get the basic field you wanna to query
                    let regexFieldAttr =  Object.keys(basicCard).filter(a=>a.toLowerCase().match(fieldattr));
                    fieldName = regexFieldAttr[0];

                    // if no field found, it will return basic card by default
                    if (fieldName == "" || fieldName == null){
                        botRes = JSON.stringify(basicCard);
                       
                        var imageCallUrl =  hcmcommon.getPhotoUrl(conversation, firstname, lastname, username, passw);

                        var cardsTemplate = {
                         "type": "card",
                         "layout": "horizontal",
                         "cards": []
                        };

                        var imagePath = getImage(username, passw, conversation, imageCallUrl);

                        var card = {
                                    title : firstname + " " + lastname + "'s Profile",
                                    description : botRes.trim().substring(1, botRes .length-1).replace(/"/g," ").trim().replace(/,/g, '\n'),
                                    imageUrl: imagePath,//"https://i.imgur.com/SGz1TGj.png",
                                    actions: [
                                                {
                                                    "type": "postback",
                                                    "label": "Link",
                                                    "postback": "https://ucf3-fap0345-fa-ext.oracledemos.com/"
                                                }
                                        ]
                                };

                                cardsTemplate.cards.push(card);

                            conversation.reply({ text: "Here is " + firstname + " " + lastname + "'s profile:" });
                            let message = new MessageModel(cardsTemplate);
                            conversation.reply(message.messagePayload());
                            conversation.keepTurn(true);
                    }else{
                        botRes = "The " + fieldattr + " for " +firstname + " " + lastname + " is: \n" + basicCard[fieldName];
                        //conversation.reply ({text: botRes});
                        conversation.variable("iscommon","Yes");
                        conversation.variable("basicRes", botRes.trim());
                    }
                }else{
                    botRes = "Please make sure you type the correct fullname";
                    conversation.reply({text: botRes});
                }
            }
        }else{
            botRes = "Please make sure you type the correct fullname";
            conversation.reply({text: botRes});
        }

        conversation.logger().info("state switch to: " + (isList ? 'showlist' : 'nonlist'));
        conversation.transition(isList ? 'showlist' : 'nonlist');
        done();
    }
}