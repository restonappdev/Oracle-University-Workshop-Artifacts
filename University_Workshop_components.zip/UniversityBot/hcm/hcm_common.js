"use strict"
const https = require('https');

// Helper function to truncate string
function strUtil (rawStr) {
    if(rawStr == null || rawStr == ""){
        return "";
    }else {
        let resStr = rawStr.toString().trim();
        if(resStr == ""){
            return "";
        }else{
            return resStr;
        }
    }
}

module.exports  = {
	
  // HCM Get Basic info based on firstname and lastname
  getHCMBasicBody: function(conversation, firstname, lastname, username, passw) {
  	var body = "";
    var done1 = false
  	
  	conversation.logger().info('firstname' + firstname);
  	conversation.logger().info('lastname' + lastname);
  	if ((firstname !== null || firstname !== '') && (lastname !== null || lastname !== '')){
  		
        conversation.logger().info('username' + username);
        conversation.logger().info('passw' + passw);

        // hcm api variables for querying one employee's basic info 
        var pathurl = "/hcmRestApi/resources/11.13.17.11/emps/?q=LastName="+ lastname  +";FirstName=" + firstname;
        var options = {
            "method": "GET",
            "host": "ucf1-ecwa-fa-ext.oracledemos.com",
            "path": pathurl,
            "headers": {
                "Authorization": 'Basic ' + new Buffer(username + ':' + passw).toString('base64')
            }
        };
            
        // trace and debug information to backend log
        conversation.logger().info('basic pathurl - ' + pathurl);

        var requested = https.get(options, function(res) {
        	res.on("data", function(data) {
        		body += data;
            });

            res.on("end", function(){
            	body =  JSON.parse(body);
            	done1 = true;
            });
        });
        require('deasync').loopWhile(function(){return !done1;});
    }

  	return body;
  }, 

  // HCM expanded info based on firstname and lastname
  getPhotoUrl: function(conversation, firstname, lastname, username, passw) {
    var imageCallUrl ="";
    var commonBody =  this.getHCMBasicBody(conversation, firstname,lastname, username, passw);
    if(commonBody !== "" || commonBody !== null){
      var photoUrl = commonBody.items[0].links.filter(a=>a.name=="photo")[0].href;
      var done2 = false;

      var urlArr = photoUrl.split(":443");
      var options = {
            "method": "GET",
            "host": urlArr[0].replace("https://", ""),
            "path": urlArr[1],
            "headers": {
                "Authorization": 'Basic ' + new Buffer(username + ':' + passw).toString('base64')
            }
        };

            var requested = https.get(options, function(res) {
            var body = "";

            res.on("data", function(data) {
                body += data;
                
            });

            res.on("end", function(){
                body =  JSON.parse(body);
                imageCallUrl = body.items[0].links.filter(a=>a.rel=="enclosure")[0].href;
                done2 = true;
            });
        });
         require('deasync').loopWhile(function(){return !done2;});
    }

    return imageCallUrl;
  }, 

  // HCM Get Basic Card Info
  getHCMBasicCard: function(conversation, fullname, username, passw){
    let firstname = fullname[0].trim().charAt(0).toUpperCase() + fullname[0].substring(1);
    let lastname = fullname[1].trim().charAt(0).toUpperCase() + fullname[1].substring(1);

    let basicCard;

    var commonBody =  this.getHCMBasicBody(conversation, firstname,lastname, username, passw);
    if(commonBody !== "" || commonBody !== null){
      let bodyRes = commonBody.items[0];

      // get clean phone info
      let countryCode = strUtil(bodyRes.WorkPhoneCountryCode);
      let rawPhone = strUtil(bodyRes.WorkPhoneAreaCode) + '-' + strUtil(bodyRes.WorkPhoneNumber);
      let phone = ( rawPhone == '-' ? "" : countryCode.trim() + "-"+ rawPhone.trim());

      // get clean address info
      var region;
      var region1 = strUtil(bodyRes.Region);
      var region2 = strUtil(bodyRes.Region2);
      if(region1 !== "" && region2 !== ""){
        region = region1 + " " + region2;
      }else if(region1 == "" && region2 == ""){
        region = "";
      }else{
        region = (region1==""? region2 : region1);
      }
      let rawAddress = strUtil(bodyRes.AddressLine1) +', ' +  strUtil(bodyRes.City) 
                      + ', ' + String(region + ' ' 
                      + strUtil(bodyRes.PostalCode)).trim()
                      + ', ' + strUtil(bodyRes.Country); 

      var commoaList = ["0, ,", ", ,", ", ,  ,", ", , ,"];
      let address = (commoaList.includes(rawAddress.trim()) ? "" : rawAddress.trim());

      // create basic card info
      basicCard = {"Firstname": strUtil(bodyRes.FirstName),
        "Lastname": strUtil(bodyRes.LastName),
        "Email": strUtil(bodyRes.WorkEmail),
        "Workphone": phone,
        "Address": address,
        "Maritalstatus": strUtil(bodyRes.MaritalStatus)
      };
    }

    return basicCard;
  },

  // HCM Get Reportees based on fullname
  getHCMReportee: function(conversation, fullname, username, passw){
    let firstname = fullname[0].trim().charAt(0).toUpperCase() + fullname[0].substring(1);
    let lastname = fullname[1].trim().charAt(0).toUpperCase() + fullname[1].substring(1);
    var reporeeStr = "";

    conversation.logger().info('username' + username);
    conversation.logger().info('passw' + passw);

    var commonBody =  this.getHCMBasicBody(conversation, firstname,lastname, username, passw);
    if(commonBody !== ""){
            var empId = commonBody.items[0].links[0].href.match("emps\/.*")[0];
            var reportees = [];            
            var done2 = false;

            // hcm api variables for querying one employee's basic info 
            var pathurl = "/hcmRestApi/resources/11.13.17.11/" + empId + "/child/directReports?fields=FullName";
            var options = {
                "method": "GET",
                "host": "ucf1-ecwa-fa-ext.oracledemos.com",
                "path": pathurl,
                "headers": {
                    "Authorization": 'Basic ' + new Buffer(username + ':' + passw).toString('base64')
                }
            };

            // trace and debug information to backend log
            conversation.logger().info('reportee pathurl is: ' + pathurl);
            
            var requested = https.get(options, function(res) {
            var body = "";

            res.on("data", function(data) {
                body += data;
                
            });

            res.on("end", function(){
                body =  JSON.parse(body);
                var bodyRes = body.items;

                var reportees = [];
                for(var i=0;i < bodyRes.length;i++){
                    var fullname = bodyRes[i].FullName.split(',');
                    var newname = fullname[1] + ' ' + fullname[0];
                    reportees.push(newname);
                }

                reporeeStr = reportees.join(',').toString();
                done2 = true;
            });
        });
         require('deasync').loopWhile(function(){return !done2;});
      }
      return reporeeStr;
  }

}











