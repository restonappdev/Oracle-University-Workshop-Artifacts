
"use strict"
const https = require('https');
const hcmcommon =require("./hcm_common.js");

module.exports = {

    metadata: () => ({
        "name": "HCMUpdateService",
        "properties": {
            "fullname" : { "type" : "string", "required": true },
            "updatefield" : { "type" : "string", "required": true},
            "updateinfo" : { "type" : "string", "required" : true},
            "testu":  {"type": "string", "required": true},
            "testp" :  {"type": "string", "required": true}
        },

        "supportedActions": []
    }),

    invoke: (conversation, done) => {
        var botRes = "";

        // Get query parameters' value from bot converstation
        let fullname = String(conversation.properties().fullname).trim().toLowerCase().split(' ');
        let firstname = fullname[0].trim().charAt(0).toUpperCase() + fullname[0].substring(1);
        let lastname = fullname[1].trim().charAt(0).toUpperCase() + fullname[1].substring(1);

        let updatefield = String(conversation.properties().updatefield).trim().toLowerCase();
        let updateinfo = String(conversation.properties().updateinfo).trim();

        // basic auth username and password
        let username = String(conversation.properties().testu);
        let passw  = String(conversation.properties().testp);

        var commonBody =  hcmcommon.getHCMBasicBody(conversation, firstname,lastname, username, passw);
         if(commonBody !== '' || commonBody !== null){
            var empId = commonBody.items[0].links[0].href.match("emps\/.*")[0];

            var options = {
                "method": "PATCH",
                "host": "ucf1-ecwa-fa-ext.oracledemos.com",
                "path":"/hcmRestApi/resources/11.13.17.11/" + empId,
                "headers": {
                    "Content-Type": "application/vnd.oracle.adf.resourceitem+json",
                    "Authorization": 'Basic ' + new Buffer(username + ':' + passw).toString('base64')
                }
            };

            var req = https.request(options, function (res) {
                var chunks = [];

                res.on("data", function (chunk) {
                    chunks.push(chunk);
                });

                var body;
                res.on("end", function () {
                    body = Buffer.concat(chunks);
                    conversation.logger().info(body.toString());
                }); 
            });

            let basicCard = hcmcommon.getHCMBasicCard(conversation, fullname, username, passw);
            if(typeof basicCard !== "undefined"){
                var rawBody;
                switch(updatefield) {
                    // format: (0-000-000-0000)
                    case "phone":
                        var phoneList = updateinfo.split('-');
                        var countryCode = phoneList[0].trim();
                        var areaCode = phoneList[1].trim();
                        var phoneNum = phoneList[2].trim() + '-' + phoneList[3].trim(); 
                        rawBody = "{\n\"WorkPhoneCountryCode\": \"" + countryCode + "\", \
                        \n\"WorkPhoneAreaCode\": \"" + areaCode + "\", \
                        \n\"WorkPhoneNumber\": \"" + phoneNum + "\"\n}";
                        break;
                        
                    // format: (address1, city, state zipcode, country)
                    case "address":
                        var addressList = updateinfo.split(',');
                        var addressLine1 = addressList[0].trim();
                        var city = addressList[1].trim();
                        var stateZip = addressList[2].trim().split(' ');
                        var region = stateZip[0];
                        var zipcode = stateZip[1];
                        var country = addressList[3].trim();
    
                        rawBody = "{\n\"AddressLine1\": \"" + addressLine1 + "\", \
                        \n\"City\": \"" + city + "\", \
                        \n\"Region\": \"" + region + "\",\
                        \n\"Country\": \"" + country + "\", \
                        \n\"PostalCode\": \"" + zipcode + "\"\n}";
                        break;
                    case "email":
                        rawBody = "{\n\"WorkEmail\": \"" + updateinfo + "\"\n}";
                        break;
                    case "firstname":
                        rawBody = "{\n\"FirstName\": \"" + updateinfo + "\"\n}";;
                        break;
                    case "lastname":
                        rawBody = "{\n\"LastName\": \"" + updateinfo + "\"\n}";;
                        break;
                    case "maritalstatus":
                        rawBody = "{\n\"MaritalStatus\": \"" + updateinfo + "\"\n}";
                        break;
                    default:
                        rawBody ="";
                }


            }else{
                botRes = "Please make sure you type the correct fullname";
                conversation.reply({text: botRes});
            }
            
            conversation.logger().info("RawBody" + rawBody);
            req.write(rawBody);
            req.end();
            
         }

        conversation.transition();
        done();
    }
};
