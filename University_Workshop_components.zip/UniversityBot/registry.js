module.exports = {
  components: {
    // Univeristy -> HCM - Basic Web Service Component
    'HCMBasicWebService' : require('./hcm/hcm_basic'),
    // University -> HCM - Reportee Web Service Component
    'HCMReporteeService' : require('./hcm/hcm_reportee'),
    // University -> HCM - Update Web Service Component
    'HCMUpdateService' : require('./hcm/hcm_update')
  }
};
